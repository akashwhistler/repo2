package restassured;

public class q4 {

}
